-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: j5a206.p.ssafy.io    Database: study
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('abc','abc','abc','{bcrypt}$2a$10$rcPCp7OxZTCK509upZ1MPuGY9TDlBAm5B0lOJGQAKAZQ4xsnKb0Uy','abc'),('ASD','ASD','ASD','{bcrypt}$2a$10$jRENv255584PlzsiQuJ4M.KMdxnQgMnSfxXmg/mBMehS.DRsUnJ92','ASD'),('gkstkdwls','한상진','호놀룰루','{bcrypt}$2a$10$TEgpuA9zxKeAHj8xawAD9.nYgGbKOq18ygsLz6m2bKTcozpMbL4Ke','01022159921'),('jyp1231','진영팍','jyp','{bcrypt}$2a$10$PCVdZUDIVAe/TqwHq//AuO989SXBKqscvUwZZJiw9C.qgSdwmssra','01013123231'),('lhs7615','이현송','하하','{bcrypt}$2a$10$hY6twhPQUcMeTdvezPGK2.1vtOZbTmctuLqvg/7M.17vNzHOILcMG','01020867615'),('signuptest','가나다','회원가입테스트','{bcrypt}$2a$10$5hj9NQoq0Uf55lDT0obUdu8mD5cxMghFxmQDFjx7YvOrcY6aGbKTW','010-0000-0000'),('signuptest2','회테','회테','{bcrypt}$2a$10$dPm9pBz6Pm9h9qWWrDpwu.XybSOjhELPjFsZp5Atdphi45N0GTF8S','010-0000-0000'),('signuptest3','회테중','회테중','{bcrypt}$2a$10$F5tCj/wmWM/ZPhkhinyxiOT10GeTeEDWRX8HfNJ6dsWuEzWfpkQg6','010-0000-0000'),('sut4','123','123','{bcrypt}$2a$10$ddAn9g/ltYK3mRqrff4Z4ekIx2eQHW0kqV6u0pxNZ997ORcZCwjOe','123'),('sut5','123','123','{bcrypt}$2a$10$0RKtNa5QUP0421s4o0JDJ.4qJNbDnLjBJMF8Yu7JvSanqiF1QOmX2','123'),('sutfinal','1234','1234','{bcrypt}$2a$10$JdZYwHzT5XG/gzhdnUiUuODD4R6dvz/B02kbNo7NkY8W4lXzuNXiK','1234'),('test','시은','test','{bcrypt}$2a$10$QssC4AG2kLCbVyhhhXy9iePZq9SOYOXAKPiXfdm7UHifIPNyp3PLe','010-1234-5678'),('testUser','test','test','{bcrypt}$2a$10$8SFOgGX/nd0Cz5VbE.25YOee3whOL0zooRtKmCyZx/0f7q5NqORja','010-1234-1234'),('uccuser','유씨씨','ucc전용','{bcrypt}$2a$10$1Dz3paEjH1bN/XMAhDPKGuJa61lyyT/K/ky8EV0fZdUCdxdwgYlUy','010-1234-5678');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  9:39:36
