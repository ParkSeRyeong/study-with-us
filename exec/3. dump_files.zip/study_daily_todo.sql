-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: j5a206.p.ssafy.io    Database: study
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `daily_todo`
--

DROP TABLE IF EXISTS `daily_todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_todo` (
  `todo_pk` int NOT NULL AUTO_INCREMENT,
  `daily_pk` int NOT NULL,
  `todo` varchar(45) NOT NULL,
  `done` tinyint DEFAULT '1',
  PRIMARY KEY (`todo_pk`),
  KEY `daily_pk` (`daily_pk`),
  CONSTRAINT `daily_todo_ibfk_1` FOREIGN KEY (`daily_pk`) REFERENCES `daily_study` (`daily_pk`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='todo 리스트 작성';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_todo`
--

LOCK TABLES `daily_todo` WRITE;
/*!40000 ALTER TABLE `daily_todo` DISABLE KEYS */;
INSERT INTO `daily_todo` VALUES (1,1,'알고리즘 문제 풀기',0),(2,1,'JPA 공부하기',1),(3,2,'VUEX 정리하기',0),(4,2,'Front 코드 리팩토링',0),(5,7,'노트 정리',1),(6,7,'알고리즘 리뷰하기',0),(7,7,'Dijkstra 이론 공부',1),(16,11,'JWT Validation Interceptor 수정',0),(17,11,'decoding 정리하기',0),(18,11,'todo-list 구현',0),(19,11,'JIRA 등록',1),(40,8,'FE 컴포넌트 트리 짜기',1),(41,8,'화면 설계하기',0),(42,8,'할 일 추가 1',1),(43,8,'할일추가2',0),(49,15,'할 일 다시',0),(50,15,'할 일 2',0),(51,9,'123',1),(67,16,'할 일 new',0),(111,17,'git 1일 1커밋',0),(112,17,'CS 인강 듣기',0),(142,19,'수능특강 1회독',0),(143,19,'모의고사 1회',0),(144,19,'쎈 c단계 풀기',1),(145,19,'공부 3시간',1);
/*!40000 ALTER TABLE `daily_todo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  9:39:38
