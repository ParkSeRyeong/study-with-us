-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: j5a206.p.ssafy.io    Database: study
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `saying`
--

DROP TABLE IF EXISTS `saying`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saying` (
  `saying_pk` int NOT NULL AUTO_INCREMENT,
  `quote` varchar(200) NOT NULL,
  PRIMARY KEY (`saying_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='명언';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saying`
--

LOCK TABLES `saying` WRITE;
/*!40000 ALTER TABLE `saying` DISABLE KEYS */;
INSERT INTO `saying` VALUES (1,'목표를 낮추지 말고 노력을 높여라'),(2,'지금 포기하지 않으면 네 꿈을 포기하지 않아도 돼.'),(4,'포기하는 순간 다른 사람에게 기회가'),(5,'하기 싫은걸 해야 하고 싶은걸 한다.'),(7,'기회는 일어나는 것이 아니라 만들어내는 것이다'),(8,'무언가를 시작하려면 말은 멈추고 행동해야 한다.'),(9,'잠을 자면 꿈을 꾸지만 공부를 하면 꿈을 이룬다.'),(10,'What we dwell on is who we become.'),(12,'You will never know until you try.'),(13,'Well done is better than well said.'),(14,'Let bygones be bygones.'),(16,'You create your opportunities by asking for them.'),(17,'어제 너는 내일이라고 말했다. 그냥 해.'),(18,'성과는 요령 피우지 않을 때 생긴다.'),(19,'All progress takes place outside the comfort zone.');
/*!40000 ALTER TABLE `saying` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  9:39:37
